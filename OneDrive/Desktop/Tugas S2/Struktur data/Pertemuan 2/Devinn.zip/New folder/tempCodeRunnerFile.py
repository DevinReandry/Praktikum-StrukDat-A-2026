nilai.pop(3)
print(nilai)